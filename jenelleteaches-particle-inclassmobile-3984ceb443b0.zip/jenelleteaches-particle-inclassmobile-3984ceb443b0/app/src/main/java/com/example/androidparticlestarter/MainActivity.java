package com.example.androidparticlestarter;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.IOException;
import java.io.StreamCorruptedException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import io.particle.android.sdk.cloud.ParticleCloud;
import io.particle.android.sdk.cloud.ParticleCloudSDK;
import io.particle.android.sdk.cloud.ParticleDevice;
import io.particle.android.sdk.cloud.ParticleEvent;
import io.particle.android.sdk.cloud.ParticleEventHandler;
import io.particle.android.sdk.cloud.exceptions.ParticleCloudException;
import io.particle.android.sdk.utils.Async;

public class MainActivity extends AppCompatActivity {
    // MARK: Debug info
    private final String TAG="JENELLE";

    // MARK: Particle Account Info
    private final String PARTICLE_USERNAME = "rammi.0446@gmail.com";
    private final String PARTICLE_PASSWORD = "ramandeep09";

    // MARK: Particle device-specific info
    private final String DEVICE_ID = "2a002f000f47363333343437";
    String[] words = {"dog","cow","rat","banana","apple"};
    Random random;
    String deviceOutput = "";
    String deviceIDOutput = "";
    int scoreRaman = 0;
    int scoreSagar = 0;
    int scoreManpreet = 0;
    // MARK: Particle Publish / Subscribe variables
    private long subscriptionId;

    // MARK: Particle device
    private List<ParticleDevice> mDevice;
    TextView red;
    TextView score1;
    TextView score2;
    TextView score3;
    TextView winnerTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Initialize your connection to the Particle API
        ParticleCloudSDK.init(this.getApplicationContext());

        // 2. Setup your device variable
        getDeviceFromCloud();

        //get ouput from devices
        random = new Random();
        red = (TextView)findViewById(R.id.red);
        score1 = (TextView)findViewById(R.id.score1);
        score2 = (TextView)findViewById(R.id.score2);
        score3 = (TextView) findViewById(R.id.score3);
        winnerTextView = (TextView) findViewById(R.id.winner);
        setQuestion();
//        red.setText("dog");

    }


    /**
     * Custom function to connect to the Particle Cloud and get the device
     */
    public void getDeviceFromCloud() {
        // This function runs in the background
        // It tries to connect to the Particle Cloud and get your device
        Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

            @Override
            public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {
                particleCloud.logIn(PARTICLE_USERNAME, PARTICLE_PASSWORD);
               // mDevice = particleCloud.getDevice(DEVICE_ID);
                mDevice = particleCloud.getDevices();
                Log.d("devices all ",mDevice.toString());
                return -1;
            }

            @Override
            public void onSuccess(Object o) {
                Log.d(TAG, "Successfully got device from Cloud");
            }

            @Override
            public void onFailure(ParticleCloudException exception) {
                Log.d(TAG, exception.getBestMessage());
            }
        });
    }


//    public void changeColorsPressed(View view) {
//        Log.d("JENELLE", "Button pressed;");
//
//        // logic goes here
//
//        // 1. get the r,g,b value from the UI
//        EditText red = (EditText) findViewById(R.id.red);
//
//
//        // Convert these to strings
//        String r = red.getText().toString();
//
//
//        Log.d(TAG, "Red: " + r);
//
//        String commandToSend = r ;
//        Log.d(TAG, "Command to send to particle: " + commandToSend);
//
//
//        Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {
//            @Override
//            public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {
//
//                // 2. build a list and put the r,g,b into the list
//                List<String> functionParameters = new ArrayList<String>();
//                functionParameters.add(commandToSend);
//
//                // 3. send the command to the particle
//                try {
//                    mDevice.callFunction("colors", functionParameters);
//                } catch (ParticleDevice.FunctionDoesNotExistException e) {
//                    e.printStackTrace();
//                }
//
//                return -1;
//            }
//
//            @Override
//            public void onSuccess(Object o) {
//                Log.d(TAG, "Sent colors command to device.");
//            }
//
//            @Override
//            public void onFailure(ParticleCloudException exception) {
//                Log.d(TAG, exception.getBestMessage());
//            }
//        });
//
//    }
//

    public void subscribeButtonPressed(View view) {
        Log.d(TAG, "Subscribe button pressed");
    }

    public void changeColorsPressed(View view)
    {
        Log.d(TAG, "Subscribe button pressed");


        // check if device is null
        // if null, then show error
        if (mDevice == null) {
            Log.d(TAG, "Cannot find device");
            return;
        }


        Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

            @Override
            public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {
                subscriptionId = ParticleCloudSDK.getCloud().subscribeToAllEvents(
                        "broadcastMessage",  // the first argument, "eventNamePrefix", is optional
                        new ParticleEventHandler() {
                            public void onEvent(String eventName, ParticleEvent event) {
                                Log.i(TAG, "Received event with payload: " + event.dataPayload);
                                Log.i(TAG, "Received event with id: " + event.deviceId);
                                deviceOutput = event.dataPayload;
                                deviceIDOutput = event.deviceId;


                                sendData();

                            }

                            public void onEventError(Exception e) {
                                Log.e(TAG, "Event error: ", e);
                            }
                        });


                return -1;
            }

            @Override
            public void onSuccess(Object o) {
                Log.d(TAG, "Successfully got device from Cloud");
            }

            @Override
            public void onFailure(ParticleCloudException exception) {
                Log.d(TAG, exception.getBestMessage());
            }
        });


    }

    public void sendData()
    {
        Log.d(TAG,"send data function call " + deviceOutput);
        String commandToSend = "";
        if(deviceIDOutput.equals("2a002f000f47363333343437"))
        {
            Log.d(TAG,"device id raman------------------------");
            if(deviceOutput.equals("1") && (red.getText() == words[0] || red.getText() == words[1] || red.getText() == words[2] ))
            {
                Log.d(TAG,"compare here if");
                //1 is for true and 3 is for false
                commandToSend = "1";
                scoreRaman = scoreRaman + 1;
                Log.d(TAG,"score Raman "+scoreRaman);
            }
            else if(deviceOutput.equals("1") && (red.getText() == words[3] || red.getText() == words[4] ))
            {
                Log.d(TAG,"compare here else if");
                commandToSend = "3";

            }
            else if(deviceOutput.equals("3") && (red.getText() == words[0] || red.getText() == words[1] || red.getText() == words[2] ))
            {
                Log.d(TAG,"compare here else if");
                //1 is for true and 3 is for false
                commandToSend = "3";
            }
            else if(deviceOutput.equals("3") && (red.getText() == words[3] || red.getText() == words[4] ))
            {
                Log.d(TAG,"compare here else if");
                commandToSend = "1";
                scoreRaman = scoreRaman + 1;
                Log.d(TAG,"score Raman "+scoreRaman);
            }


        }


        else if(deviceIDOutput.equals("420031000f47363333343437"))
        {
            Log.d(TAG,"device id sagar------------------------");

            if(deviceOutput.equals("1") && (red.getText() == words[0] || red.getText() == words[1] || red.getText() == words[2] ))
            {
                Log.d(TAG,"compare here if");
                //1 is for true and 3 is for false
                commandToSend = "1";
                scoreSagar = scoreSagar + 1;
                Log.d(TAG,"score sagar "+scoreSagar);
            }
            else if(deviceOutput.equals("1") && (red.getText() == words[3] || red.getText() == words[4] ))
            {
                Log.d(TAG,"compare here else if");
                commandToSend = "3";

            }
            else if(deviceOutput.equals("3") && (red.getText() == words[0] || red.getText() == words[1] || red.getText() == words[2] ))
            {
                Log.d(TAG,"compare here else if");
                //1 is for true and 3 is for false
                commandToSend = "3";
            }
            else if(deviceOutput.equals("3") && (red.getText() == words[3] || red.getText() == words[4] ))
            {
                Log.d(TAG,"compare here else if");
                commandToSend = "1";
                scoreSagar = scoreSagar + 1;
                Log.d(TAG,"score sagar "+scoreSagar);
            }

        }


        else if(deviceIDOutput.equals("36001b001047363333343437"))
        {
            Log.d(TAG,"device id manpreet----------------------");
            if(deviceOutput.equals("1") && (red.getText() == words[0] || red.getText() == words[1] || red.getText() == words[2] ))
            {
                Log.d(TAG,"compare here if");
                //1 is for true and 3 is for false
                commandToSend = "1";
                scoreManpreet = scoreManpreet + 1;
                Log.d(TAG,"score Manpreet "+scoreManpreet);
            }
            else if(deviceOutput.equals("1") && (red.getText() == words[3] || red.getText() == words[4] ))
            {
                Log.d(TAG,"compare here else if");
                commandToSend = "3";

            }
            else if(deviceOutput.equals("3") && (red.getText() == words[0] || red.getText() == words[1] || red.getText() == words[2] ))
            {
                Log.d(TAG,"compare here else if");
                //1 is for true and 3 is for false
                commandToSend = "3";
            }
            else if(deviceOutput.equals("3") && (red.getText() == words[3] || red.getText() == words[4] ))
            {
                Log.d(TAG,"compare here else if");
                commandToSend = "1";
                scoreManpreet = scoreManpreet + 1;
                Log.d(TAG,"score Manpreet "+scoreManpreet);
            }

        }

        Log.d(TAG,"command to send "+commandToSend);
        String finalCommandToSend = commandToSend;
        int finalScoreRaman = scoreRaman;
        int finalScoresagar = scoreSagar;
        int finalScoreManpreet = scoreManpreet;
        Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {
            @Override
            public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {

                // 2. build a list and put the r,g,b into the list
                List<String> functionParameters = new ArrayList<String>();
                functionParameters.add(finalCommandToSend);
                functionParameters.add(String.valueOf(finalScoreRaman));
                functionParameters.add(String.valueOf(finalScoresagar));
                functionParameters.add(String.valueOf(finalScoreManpreet));

                // 3. send the command to the particle
                try {
                    ParticleDevice devicem = particleCloud.getDevice(deviceIDOutput);
                    devicem.callFunction("colors", functionParameters);

                } catch (ParticleDevice.FunctionDoesNotExistException e) {
                    e.printStackTrace();
                }

                return -1;
            }

            @Override
            public void onSuccess(Object o) {
                Log.d(TAG, "Successfully send data to cloud");
            }

            @Override
            public void onFailure(ParticleCloudException exception) {
                Log.d(TAG, exception.getBestMessage());
            }
        });
    }

    public void setQuestion() {
        int n = random.nextInt(5);
        red.setText(words[n]);
    }

    public void checkScoresPressed(View view)
    {
        score1.setText("raman score : " +String.valueOf(scoreRaman));
        score2.setText("sagar score : " +String.valueOf(scoreSagar));
        score3.setText("Manpreet score : " +String.valueOf(scoreManpreet));

    }

    public void playAgain(View view)
    {
        setQuestion();
        if(scoreRaman >= 2) {
            String winner = "raman is winner";
            Log.d(TAG,"raman is winner and score are : "+scoreRaman);
            winnerTextView.setText("winner is Raman");
            scoreRaman = 0;
            scoreSagar = 0;
            scoreManpreet = 0;
            score1.setText("raman score : " +String.valueOf(scoreRaman));
            score2.setText("sagar score : " +String.valueOf(scoreSagar));
            score3.setText("Manpreet score : " +String.valueOf(scoreManpreet));

        }
        else if(scoreSagar >= 2)
        {
            String winner = "sagar is winner";
            winnerTextView.setText("winner is Sagar");
            Log.d(TAG,"sagar is winner and score are : "+scoreSagar);
            scoreRaman = 0;
            scoreSagar = 0;
            scoreManpreet = 0;
            score1.setText("raman score : " +String.valueOf(scoreRaman));
            score2.setText("sagar score : " +String.valueOf(scoreSagar));
            score3.setText("Manpreet score : " +String.valueOf(scoreManpreet));

        }
        else if(scoreManpreet >= 2)
        {
            String winner = "Manpreet is winner";
            winnerTextView.setText("winner is Manpreet");
            Log.d(TAG," Manpreet is winner and score are : "+scoreManpreet);
            scoreRaman = 0;
            scoreSagar = 0;
            scoreManpreet = 0;
            score1.setText("raman score : " +String.valueOf(scoreRaman));
            score2.setText("sagar score : " +String.valueOf(scoreSagar));
            score3.setText("Manpreet score : " +String.valueOf(scoreManpreet));

        }

    }
}
